<?php
include ('header.php');
include ('leftsidbar.php');

?>
<!-- main Content -->
    <!--Mainbody-->
    <div class="col-md-7 bg-dark mt-3">
      <h1> This is my about page</h1>


    </div>

<?php
include ('rightsidbar.php');

include ('footer.php');

?>