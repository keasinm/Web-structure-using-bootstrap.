<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="asets/css/bootstrap.min.css">
    <link rel="stylesheet" href="asets/css/style.css">
    <title>Document</title>
</head>
<body>
<div>
    <!--Navsection-->
    <nav class="navbar navbar-expand-lg text-co bg-dark  ">
        <a class="navbar-brand " href="index.php"><img src="asets/images/tooplate_logo.png" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active ">
                    <a class="nav-link text-info" href="index.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active ">
                    <a class="nav-link text-info" href="signin.php">Sign Up <span class="sr-only">(current)</span></a>
                </li>

            </ul>
            <form class="form-inline my-2 my-lg-0">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-info  my-2 my-sm-0" type="submit">Search</button>
            </form>
        </div>
    </nav>
</div>
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8 bg-dark   mt-3 mb-3 ">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-login mx-auto">
                    <div class="text-center mt-4 mb-3">
                        <img src="asets/images/tooplate_logo.png" class="h-6" alt="InfinityFree">
                    </div>
                    <form class="card" action="https://app.infinityfree.net/login" method="post" id="auth-form">
                        <input type="hidden" name="_token" value="">
                        <div class="card-body p-6">
                            <div class="card-title">Login to your account</div>
                            <div class="form-group">
                                <label class="form-label" for="email">Email Address</label>
                                <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="you@example.com" required="">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="password">
                                    Password
                                    <a href="" class="float-right ">I forgot my password</a>
                                </label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="hunter2" required="">
                            </div>
                            <div class="form-group">
                                <label class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" name="remember">
                                    <span class="custom-control-label">Remember me</span>
                                </label>
                            </div>
                            <div class="form-footer">
                                <div><div class="grecaptcha-badge" data-style="bottomright" style="width: 256px; height: 60px; display: block; transition: right 0.3s ease 0s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px; border-radius: 2px; overflow: hidden;"><div class="grecaptcha-logo"><iframe src="https://www.google.com/recaptcha/api2/anchor?ar=1&amp;k=6LcmctsUAAAAAAp-62RRXCgoifK8A1TbjwWqrLS8&amp;co=aHR0cHM6Ly9hcHAuaW5maW5pdHlmcmVlLm5ldDo0NDM.&amp;hl=en&amp;v=4lbq4vBYAu25DMtzZ7GGbfAF&amp;size=invisible&amp;cb=661img4f0obb" width="256" height="60" role="presentation" name="a-guhv8e7utihh" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><div class="grecaptcha-error"></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div><iframe style="display: none;"></iframe></div><button type="submit" class="btn btn-primary btn-block g-recaptcha" data-sitekey="6LcmctsUAAAAAAp-62RRXCgoifK8A1TbjwWqrLS8" data-callback="submitForm">Sign in</button>
                            </div>
                        </div>
                    </form>
                    <div class="text-center text-muted">
                        Don't have account yet? <a href="signin.php">Sign up</a>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <div class="col-md-2"></div>
</div>


<div class="text-center badge-dark text-white ">
    <h6 class="py-3"> Copyright@inews</h6>

</div>

<script type="text/javascript" src="asets/js/jquery-3.5.1.slim.min.js"></script>
<script type="text/javascript" src="asets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="asets/js/bootstrap.bundle.js"></script>
<script type="text/javascript" src="asets/js/jquery-3.5.1.slim.min.js"></script>
<script type="text/javascript" src="asets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="asets/js/bootstrap.bundle.js"></script>


</body>
</html>
